<?php

namespace ESIEA\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESIEAPlatformBundle extends Bundle
{
}
