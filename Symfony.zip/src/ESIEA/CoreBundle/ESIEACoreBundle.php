<?php

namespace ESIEA\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESIEACoreBundle extends Bundle
{
}
